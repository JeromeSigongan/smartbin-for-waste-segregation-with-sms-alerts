import RPi.GPIO as GPIO
import time
GPIO.setwarnings(False)

#Relay1
Relay2=27
Relay3=17
#Relay4
Relay5=13
Relay6=6
#Relay7
Relay8=16
Relay9=12

GPIO.cleanup()
GPIO.setmode(GPIO.BCM)


#GPIO.setup(Relay1, GPIO.OUT)
GPIO.setup(Relay2, GPIO.OUT)
GPIO.setup(Relay3, GPIO.OUT)
#GPIO.setup(Relay4, GPIO.OUT)
GPIO.setup(Relay5, GPIO.OUT)
GPIO.setup(Relay6, GPIO.OUT)
#GPIO.setup(Relay7, GPIO.OUT)
GPIO.setup(Relay8, GPIO.OUT)
GPIO.setup(Relay9, GPIO.OUT)

try:
    while True:
        #GPIO.output(Relay1,True)
        GPIO.output(Relay2,True)
        GPIO.output(Relay3,True)
        #GPIO.output(Relay4,True)
        GPIO.output(Relay5,True)
        GPIO.output(Relay6,True)
        #GPIO.output(Relay7,True)
        GPIO.output(Relay8,True)
        GPIO.output(Relay9,True)
    
except KeyboardInterrupt:
    GPIO.cleanup()