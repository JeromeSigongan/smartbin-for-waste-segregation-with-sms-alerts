import RPi.GPIO as GPIO
import time

Relay2=4
Relay3=17
Relay5=27
Relay6=5
Relay8=6
Relay9=13

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(Relay2, GPIO.OUT)
GPIO.setup(Relay3, GPIO.OUT)
GPIO.setup(Relay5, GPIO.OUT)
GPIO.setup(Relay6, GPIO.OUT)
GPIO.setup(Relay8, GPIO.OUT)
GPIO.setup(Relay9, GPIO.OUT)

while True:

#     GPIO.output(Relay2,False)
    GPIO.output(Relay2,True)
#    GPIO.output(Relay3,False)
    GPIO.output(Relay3,True)
#    GPIO.output(Relay5,False)
    GPIO.output(Relay5,True)
#     GPIO.output(Relay6,False)
#     GPIO.output(Relay6,True)
    GPIO.output(Relay8,False)
#     GPIO.output(Relay8,True)
#     GPIO.output(Relay9,False)
    GPIO.output(Relay9,True)
    
GPIO.cleanup()