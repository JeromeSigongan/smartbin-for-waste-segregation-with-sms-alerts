import RPi.GPIO as GPIO
import time

BUTTON_PIN1=16

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(BUTTON_PIN1, GPIO.IN,pull_up_down=GPIO.PUD_UP)

while True:
    input_state1 = GPIO.input(BUTTON_PIN1)
    if input_state1 == False:
        print('Button Pressed 1')
        time.sleep(0.2)
        