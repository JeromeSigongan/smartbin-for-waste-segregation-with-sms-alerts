#Non-Biodegradable Bin
import RPi.GPIO as GPIO
import time
import serial
import os, time

GPIO.setwarnings(False)
TRIG2=int(24)
ECHO2=int(23)

Relay8=16
Relay9=12

GPIO.cleanup()

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG2, GPIO.OUT)
GPIO.setup(ECHO2, GPIO.IN)

GPIO.setup(Relay8, GPIO.OUT)
GPIO.setup(Relay9, GPIO.OUT)

GPIO.output(Relay8,True)
GPIO.output(Relay9,True)

def sendSMS():
    port = serial.Serial('/dev/serial0', baudrate=9600, timeout=1)
    port.write(b'AT\r')
    rcv = port.read(10)
    print(rcv)
    time.sleep(1)        
    port.write(b"AT+CMGF=1\r")
    print("Text Mode Enabled…")
    time.sleep(3)
    port.write(b'AT+CMGS="9491500284"\r')
    msg = "WARNING:"+"\n"+"NBSC Smart Bin"+"\n"+"Non-Biodegradable Bin is full"+"\n"+"Ready to Collect!"
    print("sending message….")
    time.sleep(3)
    port.reset_output_buffer()
    time.sleep(1)
    port.write(str.encode(msg+chr(26)))
    time.sleep(3)
    print("message sent…")

while True:
    print ("Bin-3 Measurement")
    time.sleep(0.000002)
    GPIO.output(TRIG2,True)
    time.sleep(0.000010)
    GPIO.output(TRIG2,False)
    
    StartTime = time.time()
    StopTime = time.time()
    
    while GPIO.input(ECHO2)==0:
        StartTime=time.time()
    while GPIO.input(ECHO2)==1:
        StopTime=time.time()
        
    TimeElapsed = StopTime - StartTime
    distance = (TimeElapsed * 34300)/2
    distance = int(distance)
    print("Distance: %.2f cm" % (distance))
    if(distance>=0 and distance<=6):        
        GPIO.output(Relay8,False)
        GPIO.output(Relay9,False)
        print("Bin 3 is already full send SMS to utility")
        sendSMS()        
    elif(distance>=7 and distance<=33):
        GPIO.output(Relay8,True)
        GPIO.output(Relay9,False)
    else:
        GPIO.output(Relay8,True)
        GPIO.output(Relay9,True)   