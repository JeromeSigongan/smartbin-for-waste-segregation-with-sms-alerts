#Bin Levels
import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
TRIG=int(21)
ECHO=int(20)
TRIG1=int(8)
ECHO1=int(25)
TRIG2=int(24)
ECHO2=int(23)

#Relay1
Relay2=27
Relay3=17
#Relay4
Relay5=13
Relay6=6
#Relay7
Relay8=16
Relay9=12

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.setup(TRIG1, GPIO.OUT)
GPIO.setup(ECHO1, GPIO.IN)
GPIO.setup(TRIG2, GPIO.OUT)
GPIO.setup(ECHO2, GPIO.IN)

GPIO.setup(Relay2, GPIO.OUT)
GPIO.setup(Relay3, GPIO.OUT)
GPIO.setup(Relay5, GPIO.OUT)
GPIO.setup(Relay6, GPIO.OUT)
GPIO.setup(Relay8, GPIO.OUT)
GPIO.setup(Relay9, GPIO.OUT)
GPIO.setwarnings(False)

print ("Bin-1 Measurement")
time.sleep(0.000002)
GPIO.output(TRIG,True)
time.sleep(0.000010)
GPIO.output(TRIG,False)
    
StartTime = time.time()
StopTime = time.time()
    
while GPIO.input(ECHO)==0:
    StartTime=time.time()
while GPIO.input(ECHO)==1:
    StopTime=time.time()
        
TimeElapsed = StopTime - StartTime
distance = (TimeElapsed * 34300)/2
distance = int(distance)
print("Distance: %.2f cm" % (distance))

if(distance>33):
        print('Moving stepper')
        ser.write(b"CCW\n")
        time.sleep(10)
        print('Moving servo on channel 0')
        # Move servo on channel O between extremes.
        pwm.set_pwm(0, 0, servo_min)
        time.sleep(1)
        pwm.set_pwm(0, 0, servo_max)
        time.sleep(1)
        #Stepper motor back on default position
        ser.write(b"default\n")
        
        GPIO.output(Relay2,True)
        GPIO.output(Relay3,True)

elif(distance>=7 and distance<=33):
        print('Moving stepper')
        ser.write(b"CCW\n")
        time.sleep(10)
        print('Moving servo on channel 0')
        # Move servo on channel O between extremes.
        pwm.set_pwm(0, 0, servo_min)
        time.sleep(1)
        pwm.set_pwm(0, 0, servo_max)
        time.sleep(1)
        #Stepper motor back on default position
        ser.write(b"default\n")
    
    GPIO.output(Relay2,True)
    GPIO.output(Relay3,False)
        
elif(distance>=0 and distance<=3):        
    GPIO.output(Relay2,False)
    GPIO.output(Relay3,False)
    print("Bin 1 is already full send SMS to utility")
    sendSMS1()        
        
print ("Bin-2 Measurement")
time.sleep(0.000002)
GPIO.output(TRIG1,True)
time.sleep(0.000010)
GPIO.output(TRIG1,False)
    
StartTime = time.time()
StopTime = time.time()
    
while GPIO.input(ECHO1)==0:
    StartTime=time.time()
while GPIO.input(ECHO1)==1:
    StopTime=time.time()
        
TimeElapsed = StopTime - StartTime
distance = (TimeElapsed * 34300)/2
distance = int(distance)
print("Distance: %.2f cm" % (distance))

if(distance>33):    
    print('Moving servo on channel 0')
    # Move servo on channel O between extremes.
    pwm.set_pwm(0, 0, servo_min)
    time.sleep(1)
    pwm.set_pwm(0, 0, servo_max)
    time.sleep(1)
    
    GPIO.output(Relay5,True)
    GPIO.output(Relay6,True)

elif(distance>=7 and distance<=33):
    print('Moving servo on channel 0')
    # Move servo on channel O between extremes.
    pwm.set_pwm(0, 0, servo_min)
    time.sleep(1)
    pwm.set_pwm(0, 0, servo_max)
    time.sleep(1)
    
    GPIO.output(Relay5,True)
    GPIO.output(Relay6,False)
    
elif(distance>=0 and distance<=6):        
    GPIO.output(Relay5,False)
    GPIO.output(Relay6,False)
    print("Bin 2 is already full send SMS to utility")
    sendSMS2()
        
print ("Bin-3 Measurement")
time.sleep(0.000002)
GPIO.output(TRIG2,True)
time.sleep(0.000010)
GPIO.output(TRIG2,False)
    
StartTime = time.time()
StopTime = time.time()
    
while GPIO.input(ECHO2)==0:
    StartTime=time.time()
while GPIO.input(ECHO2)==1:
    StopTime=time.time()
        
TimeElapsed = StopTime - StartTime
distance = (TimeElapsed * 34300)/2
distance = int(distance)
print("Distance: %.2f cm" % (distance))

if(distance>33):
    print('Moving stepper')
    ser.write(b"CW\n")
    time.sleep(10)
    print('Moving servo on channel 0')
    # Move servo on channel O between extremes.
    pwm.set_pwm(0, 0, servo_min)
    time.sleep(1)
    pwm.set_pwm(0, 0, servo_max)
    time.sleep(1)
    #Stepper motor back on default position
    ser.write(b"default\n")    
    
    GPIO.output(Relay8,True)
    GPIO.output(Relay9,True)  

elif(distance>=7 and distance<=33):
    print('Moving stepper')
    ser.write(b"CW\n")
    time.sleep(10)
    print('Moving servo on channel 0')
    # Move servo on channel O between extremes.
    pwm.set_pwm(0, 0, servo_min)
    time.sleep(1)
    pwm.set_pwm(0, 0, servo_max)
    time.sleep(1)
    #Stepper motor back on default position
    ser.write(b"default\n")
    
    GPIO.output(Relay8,True)
    GPIO.output(Relay9,False)
    
if(distance>=0 and distance<=6):        
    GPIO.output(Relay8,False)
    GPIO.output(Relay9,False)
    print("Bin 3 is already full send SMS to utility")
    sendSMS3()
   
GPIO.cleanup()