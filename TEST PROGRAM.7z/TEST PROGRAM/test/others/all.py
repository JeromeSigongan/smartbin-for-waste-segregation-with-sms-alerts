import os

os.system('python3 /home/pi/smartbin/ML.py & python3 /home/pi/smartbin/Bin1.py & python3 /home/pi/smartbin/Bin2.py & python3 /home/pi/smartbin/Bin3.py')