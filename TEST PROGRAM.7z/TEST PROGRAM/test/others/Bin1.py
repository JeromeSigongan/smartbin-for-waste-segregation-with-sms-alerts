#Biodegradable Bin
import RPi.GPIO as GPIO
import time
import serial
import os, time

port = serial.Serial('/dev/serial0', baudrate=9600, timeout=1)

GPIO.setwarnings(False)
TRIG=int(21)
ECHO=int(20)

#Relay1
Relay2=27
Relay3=17

GPIO.cleanup()

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

GPIO.setup(Relay2, GPIO.OUT)
GPIO.setup(Relay3, GPIO.OUT)

GPIO.output(Relay2, True)
GPIO.output(Relay3,True)

def sendSMS():
    port.write(b'AT\r')
    rcv = port.read(10)
    print(rcv)
    time.sleep(1)        
    port.write(b"AT+CMGF=1\r")
    print("Text Mode Enabled…")
    time.sleep(3)
    port.write(b'AT+CMGS="9491500284"\r')
    msg = "WARNING:"+"\n"+"NBSC Smart Bin"+"\n"+"Biodegradable Bin is full"+"\n"+"Ready to Collect!"
    print("sending message….")
    time.sleep(3)
    port.reset_output_buffer()
    time.sleep(1)
    port.write(str.encode(msg+chr(26)))
    time.sleep(3)
    print("message sent…")

while True:
    print ("Bin-1 Measurement")
    time.sleep(0.000002)
    GPIO.output(TRIG,True)
    time.sleep(0.000010)
    GPIO.output(TRIG,False)
    
    StartTime = time.time()
    StopTime = time.time()
    
    while GPIO.input(ECHO)==0:
        StartTime=time.time()
    while GPIO.input(ECHO)==1:
        StopTime=time.time()
        
    TimeElapsed = StopTime - StartTime
    distance = (TimeElapsed * 34300)/2
    distance = int(distance)
    print("Distance: %.2f cm" % (distance))
    if(distance>=0 and distance<=3):        
        GPIO.output(Relay2,False)
        GPIO.output(Relay3,False)
        print("Bin 1 is already full send SMS to utility")
        sendSMS()        
    elif(distance>=7 and distance<=33):
        GPIO.output(Relay2,True)
        GPIO.output(Relay3,False)
    else:
        GPIO.output(Relay2,True)
        GPIO.output(Relay3,True)   
        