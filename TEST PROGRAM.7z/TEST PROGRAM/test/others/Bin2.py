#Recyclable Bin
import RPi.GPIO as GPIO
import time
import serial
import os, time

GPIO.setwarnings(False)
TRIG1=int(8)
ECHO1=int(25)

Relay5=13
Relay6=6

GPIO.cleanup()

GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG1, GPIO.OUT)
GPIO.setup(ECHO1, GPIO.IN)

GPIO.setup(Relay5, GPIO.OUT)
GPIO.setup(Relay6, GPIO.OUT)

GPIO.output(Relay5, True)
GPIO.output(Relay6,True)

def sendSMS():
    port = serial.Serial('/dev/serial0', baudrate=9600, timeout=1)
    port.write(b'AT\r')
    rcv = port.read(10)
    print(rcv)
    time.sleep(1)        
    port.write(b"AT+CMGF=1\r")
    print("Text Mode Enabled…")
    time.sleep(3)
    port.write(b'AT+CMGS="9491500284"\r')
    msg = "WARNING:"+"\n"+"NBSC Smart-Bin"+"\n"+"Recyclable Bin is full"+"\n"+"Ready to Collect!"
    print("sending message….")
    time.sleep(3)
    port.reset_output_buffer()
    time.sleep(1)
    port.write(str.encode(msg+chr(26)))
    time.sleep(3)
    print("message sent…")

while True:
    print ("Bin-2 Measurement")
    time.sleep(0.000002)
    GPIO.output(TRIG1,True)
    time.sleep(0.000010)
    GPIO.output(TRIG1,False)
    
    StartTime = time.time()
    StopTime = time.time()
    
    while GPIO.input(ECHO1)==0:
        StartTime=time.time()
    while GPIO.input(ECHO1)==1:
        StopTime=time.time()
        
    TimeElapsed = StopTime - StartTime
    distance = (TimeElapsed * 34300)/2
    distance = int(distance)
    print("Distance: %.2f cm" % (distance))
    if(distance>=0 and distance<=6):        
        GPIO.output(Relay5,False)
        GPIO.output(Relay6,False)
        print("Bin 2 is already full send SMS to utility")
        sendSMS()        
    elif(distance>=7 and distance<=33):
        GPIO.output(Relay5,True)
        GPIO.output(Relay6,False)
    else:
        GPIO.output(Relay5,True)
        GPIO.output(Relay6,True)   